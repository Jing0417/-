package com.Li.controller;

import com.Li.pojo.Admin;
import com.Li.pojo.Member;
import com.Li.service.AdminService;
import com.Li.service.EmployeeService;
import com.Li.service.EquipmentService;
import com.Li.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

//登陆Controller
@Controller
public class Login_Controller {

    @Autowired
    private MemberService memberService;
    @Autowired
    private AdminService adminService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private EquipmentService equipmentService;

    //第一步：主页，默认为管理员登陆界面
    @RequestMapping("/")
    public String toAdminLogin() {
        return "AdminLogin";
    }


    //第二步：进行管理员登录界面判断～
    @RequestMapping("/adminLogin")
    public String adminLogin(Admin admin, Model model, HttpSession session) {
        //判断管理员账号和密码，交给service层来处理并连接到dao层通过mapper
        //来调取数据库账号密码
        Admin admin1 = adminService.adminLogin(admin);
        if (admin1 != null) {
            //会员人数
            Integer memberTotal = memberService.selectTotalCount();
            model.addAttribute("memberTotal", memberTotal);
            session.setAttribute("memberTotal", memberTotal);

            //员工人数
            Integer employeeTotal = employeeService.selectTotalCount();
            model.addAttribute("employeeTotal", employeeTotal);
            session.setAttribute("employeeTotal", employeeTotal);

            //健身房总人数
            Integer humanTotal = memberTotal + employeeTotal;
            model.addAttribute("humanTotal", humanTotal);
            session.setAttribute("humanTotal", humanTotal);

            //器材数
            Integer equipmentTotal = equipmentService.selectTotalCount();
            model.addAttribute("equipmentTotal", equipmentTotal);
            session.setAttribute("equipmentTotal", equipmentTotal);

            return "AdminMain";
        }
        model.addAttribute("msg", "您输入的账号或密码有误，请重新输入!");
        return "AdminLogin";
    }

    //会员：跳会员登录页面～
    @RequestMapping("/toUserLogin")
    public String toUserLogin() {
        return "UserLogin";
    }

    //会员：会员登录判断
    @RequestMapping("/userLogin")
    public String userLogin(Member member, Model model, HttpSession session) {
        //同上从数据库判断账号密码
        Member member1 = memberService.userLogin(member);
        if (member1 != null) {
            model.addAttribute("member", member1);
            session.setAttribute("user", member1);
            return "UserMain";
        }
        model.addAttribute("msg", "您输入的账号或密码有误，请重新输入!");
        return "UserLogin";
    }

    //跳管理员主页～
    @RequestMapping("/toAdminMain")
    public String toAdminMain(Model model, HttpSession session) {
        Integer memberTotal = (Integer) session.getAttribute("memberTotal");
        Integer employeeTotal = (Integer) session.getAttribute("employeeTotal");
        Integer humanTotal = (Integer) session.getAttribute("humanTotal");
        Integer equipmentTotal = (Integer) session.getAttribute("equipmentTotal");
        model.addAttribute("memberTotal", memberTotal);
        model.addAttribute("employeeTotal", employeeTotal);
        model.addAttribute("humanTotal", humanTotal);
        model.addAttribute("equipmentTotal", equipmentTotal);
        return "AdminMain";
    }

    //跳会员主页～
    @RequestMapping("/toUserMain")
    public String toUserMain(Model model, HttpSession session) {
        Member member = (Member) session.getAttribute("user");
        model.addAttribute("member", member);
        return "UserMain";
    }

}
