package com.Li.service;

import com.Li.pojo.Admin;

//管理员登陆Service层～
public interface AdminService {

    //管理员登录
    Admin adminLogin(Admin admin);

}
